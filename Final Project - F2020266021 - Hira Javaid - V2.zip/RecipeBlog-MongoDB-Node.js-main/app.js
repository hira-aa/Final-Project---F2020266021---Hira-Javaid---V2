//app.js is the brain of our application and here we'll include all of the other dependencies like middlewares and here we'll create our express server

//firstly we'll require our express

const express = require('express');

//then we need express layouts which helps in creating different layouts for a webpage
const expressLayouts = require('express-ejs-layouts');
const fileUpload = require('express-fileupload');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const flash = require('connect-flash');

//for initializing new express application
const app = express();

//for setting up the port no. Here, we our manually setting the port by using localhost
const port = process.env.PORT || 4000;

//we'll also require dotenv as it will store our database details
require('dotenv').config();

//adding middlewares

//urlencoded allows us to pass url encoded bodies
app.use(express.urlencoded( { extended: true } ));

//for setting a static folder named public - static folders make the accessibility of the files easier.
app.use(express.static('public'));

//adding another middleware
app.use(expressLayouts);

app.use(cookieParser('CookingBlogSecure'));
app.use(session({
  secret: 'CookingBlogSecretSession',
  saveUninitialized: true,
  resave: true
}));
app.use(flash());
app.use(fileUpload());

//for setting layouts, we will be needing main folder
app.set('layout', './layouts/main');
//specifying the view engine and the engine we are using is ejs
app.set('view engine', 'ejs');

//for accesing the routes we will require them 
const routes = require('./server/routes/recipeRoutes.js')

//for our app to use those routes
app.use('/', routes);

//to make sure our app is listening to the port no.
app.listen(port, ()=> console.log(`Listening to port ${port}`));