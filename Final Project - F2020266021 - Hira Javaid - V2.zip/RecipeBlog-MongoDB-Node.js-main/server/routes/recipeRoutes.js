// we will include express again so that we can use the router
const express = require('express');
const router = express.Router();
//we will include the recipeController file and in order to use it we will be using module.exports to export the router
const recipeController = require('../controllers/recipeController');

/**
 * App Routes - this is where we will be listing all our pages that are connected to recipeController
*/

//router to get the homepage
router.get('/', recipeController.homepage);
//router to get recipes
router.get('/recipe/:id', recipeController.exploreRecipe );
router.get('/about', recipeController.aboutInfo );
//route to get categories
router.get('/categories', recipeController.exploreCategories);
router.get('/categories/:id', recipeController.exploreCategoriesById);
router.post('/search', recipeController.searchRecipe);
router.get('/explore-latest', recipeController.exploreLatest);
router.get('/explore-random', recipeController.exploreRandom);
router.get('/submit-recipe', recipeController.submitRecipe);
router.post('/submit-recipe', recipeController.submitRecipeOnPost);
router.get('/contact', recipeController.contactInfo);

 //exporting the router
module.exports = router;