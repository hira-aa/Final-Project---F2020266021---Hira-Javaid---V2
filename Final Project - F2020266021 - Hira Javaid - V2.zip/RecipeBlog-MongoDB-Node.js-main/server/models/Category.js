const mongoose = require('mongoose');

//creating category schema through mongoose
const categorySchema = new mongoose.Schema({
  name: {
    type: String,
    required: 'This field is required.'
  },
  image: {
    type: String,
    required: 'This field is required.'
  },
});

module.exports = mongoose.model('Category', categorySchema);

//category will be the collection name