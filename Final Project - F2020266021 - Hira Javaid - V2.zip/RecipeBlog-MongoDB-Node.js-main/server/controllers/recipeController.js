
//requiring the database
require('../models/database');
//requiring the category
const Category = require('../models/Category');
//requiring the recipe
const Recipe = require('../models/Recipe');

/**
 * GET /
 * Homepage 
*/

// in order to use this we will export the homepage which was created in recipeRoutes and it will be an asynchronous function
exports.homepage = async(req, res) => {
  try {
     //first database query to grab the category
    const limitNumber = 5;                          //no. of categories required
    const categories = await Category.find({}).limit(limitNumber);
    const latest = await Recipe.find({}).sort({_id: -1}).limit(limitNumber);
    const thai = await Recipe.find({ 'category': 'Thai' }).limit(limitNumber);
    const american = await Recipe.find({ 'category': 'American' }).limit(limitNumber);
    const chinese = await Recipe.find({ 'category': 'Chinese' }).limit(limitNumber);
    const indian = await Recipe.find({ 'category': 'Indian' }).limit(limitNumber);

    const food = { latest, thai, indian, american, chinese };

    //rendering the index page created in views
    res.render('index', { title: 'Cooking Blog - Home', categories, food } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
}

/**
 * GET /categories
 * Categories 
*/
exports.exploreCategories = async(req, res) => {
  try {
   
    const limitNumber = 20;
    const categories = await Category.find({}).limit(limitNumber);
    res.render('categories', { title: 'Cooking Blog - Categoreis', categories } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 


/**
 * GET /categories/:id
 * Categories By Id
*/
exports.exploreCategoriesById = async(req, res) => { 
  try {
    let categoryId = req.params.id;
    const limitNumber = 20;
    const categoryById = await Recipe.find({ 'category': categoryId }).limit(limitNumber);
    res.render('categories', { title: 'Cooking Blog - Categoreis', categoryById } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 
 
/**
 * GET /recipe/:id
 * Recipe 
*/
exports.exploreRecipe = async(req, res) => {
  try {
    let recipeId = req.params.id;
    const recipe = await Recipe.findById(recipeId);
    res.render('recipe', { title: 'Cooking Blog - Recipe', recipe } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 




/**
 * POST /search
 * Search 
*/
exports.searchRecipe = async(req, res) => {
  try {
    let searchTerm = req.body.searchTerm;
    let recipe = await Recipe.find( { $text: { $search: searchTerm, $diacriticSensitive: true } });
    res.render('search', { title: 'Cooking Blog - Search', recipe } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
  
}

/**
 * GET /explore-latest
 * Explore Latest 
*/
exports.exploreLatest = async(req, res) => {
  try {
    const limitNumber = 20;
    const recipe = await Recipe.find({}).sort({ _id: -1 }).limit(limitNumber);
    res.render('explore-latest', { title: 'Cooking Blog - Explore Latest', recipe } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 



/**
 * GET /explore-random
 
*/
exports.exploreRandom = async(req, res) => {
  try {
    let count = await Recipe.find().countDocuments();
    let random = Math.floor(Math.random() * count);
    let recipe = await Recipe.findOne().skip(random).exec();
    res.render('explore-random', { title: 'Cooking Blog - Explore Latest', recipe } );
  } catch (error) {
    res.satus(500).send({message: error.message || "Error Occured" });
  }
} 

/**
 * GET /about
 * About
*/
exports.aboutInfo = async(req, res) => {
  const infoErrorsObj = req.flash('infoErrors');
  const infoAboutObj = req.flash('infoAbout');
  res.render('about', { title: 'Cooking Blog - About', infoErrorsObj, infoAboutObj  } );
}



/**
 * GET /contact
 * Contact
*/
exports.contactInfo = async(req, res) => {
  const infoErrorsObj = req.flash('infoErrors');
  const infoContactObj = req.flash('infoContact');
  res.render('contact', { title: 'Cooking Blog - Contact us', infoErrorsObj, infoContactObj  } );
}



/**
 * GET /submit-recipe
 * Submit Recipe
*/
exports.submitRecipe = async(req, res) => {
  const infoErrorsObj = req.flash('infoErrors');
  const infoSubmitObj = req.flash('infoSubmit');
  res.render('submit-recipe', { title: 'Cooking Blog - Submit Recipe', infoErrorsObj, infoSubmitObj  } );
}



/**
 * POST /submit-recipe
 * Submit Recipe
*/
exports.submitRecipeOnPost = async(req, res) => {
  try {

    let imageUploadFile;
    let uploadPath;
    let newImageName;

    if(!req.files || Object.keys(req.files).length === 0){
      console.log('No Files where uploaded.');
    } else {

      imageUploadFile = req.files.image;
      newImageName = Date.now() + imageUploadFile.name;
      

      uploadPath = require('path').resolve('./') + '/public/uploads/' + newImageName;

      imageUploadFile.mv(uploadPath, function(err){
        if(err) return res.satus(500).send(err);
      })

    }

    const newRecipe = new Recipe({
      name: req.body.name,
      description: req.body.description,
      email: req.body.email,
      author: req.body.name,
      ingredients: req.body.ingredients,
      category: req.body.category,
      image: newImageName,
      createdDate: req.body.date
    });
    
    await newRecipe.save();

    req.flash('infoSubmit', 'Recipe has been added.')
    res.redirect('/submit-recipe');
  } catch (error) {
    req.flash('infoErrors', error);
    res.redirect('/submit-recipe');
  }
}


//Delete Recipe
async function deleteRecipe(){
  try {
    await Recipe.deleteOne({ name: 'chicken tandoori' });
  } catch (error) {
    console.log(error);
  }
}
deleteRecipe();


// Update Recipe
async function updateRecipe(){
  try {
    const res = await Recipe.updateOne({ name: 'Bmby' }, { name: 'Bombay Omelette' });
    res.n; // Number of documents matched
    res.nModified; // Number of documents modified
  } catch (error) {
    console.log(error);
  }
}
updateRecipe();





async function insertDymmyRecipeData(){
  try {
    await Recipe.insertMany([

      // chinese
      { 
        "name": "Stir-fried vegetables",
        "description": `Crush the garlic and finally slice the chilli and sping onions. Peel and finely chop the red onion, shred the mangetout, slice the mushrooms and water chestnuts, and mix it with the shredded cabbage in a separate bowl. Heat your wok until it's really hot. Add a splash of oil - it should start to smoke - then the chilli and onions and mix.  Source: https://www.jamieoliver.com/recipes/vegetables-recipes/stir-fried-vegetables/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 clove of garlic",
          "1 fresh red chilli",
          "3 spring onions",
          "1 small red onion",
          "1 handful og mangetout",
          "a few shiitake mushrooms",
        ],
        "category": "Chinese", 
        "image": "stir-fried-vegetables.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Spicy salt duck",
        "description": `Arrange the duck breasts, skin-side up, on a heatproof plate that will fit inside a steamer basket. Place inside the steamer and position over a deep saucepan or wok of boiling water and steam, covered, for 12 minutes or until the duck is half cooked.
        Meanwhile, in a large bowl, combine the flour, chilli powder, cumin, fennel, sichuan seasoning (see tip), ginger and 3 teaspoons of sea salt.
        Source: https://www.jamieoliver.com/recipes/duck-recipes/spicy-salt-duck/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 x 200 g duck breasts, skin on, trimmed of excess fat",
          "2 tablespoons plain flour",
          "1 teaspoon chilli powder",
          "½ teaspoon ground cumin",
        ],
        "category": "Chinese", 
        "image": "spicy-salt-duck.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Kung Pao chicken",
        "description": `Using a speed-peeler, peel the cucumber and carrot (including the skin), until you have a pile of long, thin ribbons and place in a bowl.
        Pick and roughly chop most of the coriander leaves, discarding the stalks. Place it all into the bowl with the soy and rice wine vinegar. Toss well and set aside.
        Source: https://www.jamieoliver.com/recipes/chicken-recipes/kung-pao-chicken/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 tablespoon Szechuan peppercorns",
          "2½ tablespoons cornflour",
          "4 skinless higher-welfare chicken thighs , (350g)",
          "groundnut oil , or vegetable oil",
        ],
        "category": "Chinese", 
        "image": "kung-pao-chicken.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Spring Rolls",
        "description": `Put your mushrooms in a medium-sized bowl, cover with hot water and leave for 10 minutes, or until soft. Meanwhile, place the noodles in a large bowl, cover with boiling water and leave for 1 minute. Drain, rinse under cold water, then set aside. For the filling, finely slice the cabbage and peel and julienne the carrot. Add these to a large bowl with the noodles. 
        Source: https://www.jamieoliver.com/recipes/vegetables-recipes/spring-rolls/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "40 g dried Asian mushrooms",
          "50 g vermicelli noodles",
          "200 g Chinese cabbage",
          "1 carrot",
          "3 spring onions",
          "5 cm piece of ginger",
          "1 red chilli",
         
        ],
        "category": "Chinese", 
        "image": "spring-rolls.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Chinese Steak Tofu Stew",
        "description": `Get your prep done first, for smooth cooking. Chop the steak into 1cm chunks, trimming away and discarding any fat.
        Peel and finely chop the garlic and ginger and slice the chilli. Trim the spring onions, finely slice the top green halves and put aside, then chop the whites into 2cm chunks. Peel the carrots and mooli or radishes, and chop to a similar size.
        Place a large pan on a medium-high heat and toast the Szechuan peppercorns while it heats up. Tip into a pestle and mortar, leaving the pan on the heat.
        Source: https://www.jamieoliver.com/recipes/stew-recipes/chinese-steak-tofu-stew/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "250g rump or sirloin steak",
          "2 cloves of garlic",
          "4cm piece of ginger",
          "2 fresh red chilli",
          "1 bunch of spring onions",
          "2 large carrots",
         
        ],
        "category": "Chinese", 
        "image": "chinese-steak-tofu-stew.jpg",
        "createdDate": "7/14/2022"
      },
// american

      { 
        "name": "Crab cakes",
        "description": `Trim and finely chop the spring onions, and pick and finely chop the parsley. Beat the egg.
        Combine the crabmeat, potatoes, spring onion, parsley, white pepper, cayenne and egg in a bowl with a little sea salt. Refrigerate for 30 minutes, then shape into 6cm cakes. Dust with flour and shallow-fry in oil over a medium heat for about 5 minutes each side or until golden-brown. Serve with pinches of watercress and a dollop of tartare sauce. Source: https://www.jamieoliver.com/recipes/seafood-recipes/crab-cakes/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "3 spring onions",
          "½ a bunch of fresh flat-leaf parsley",
          "1 large free-range egg",
          "750 g cooked crabmeat , from sustainable sources",
          "300 g mashed potatoes",
          "1 teaspoon ground white pepper",
          "1 teaspoon cayenne pepper",
          "plain flour , for dusting",
          "olive oil",
          "watercress",
          "tartare sauce",
        ],
        "category": "American", 
        "image": "crab-cakes.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Chocolate and Banoffee Whoopie Pies",
        "description": `Preheat the oven to 170ºC/325ºF/gas 3 and line 2 baking sheets with greaseproof paper.
        Combine the cocoa powder with a little warm water to form a paste, then add to a bowl with the remaining whoopie ingredients. Mix into a smooth, slightly stiff batter. Spoon equal-sized blobs, 2cm apart, onto the baking sheets, then place in the hot oven for 8 minutes, or until risen and cooked through.
        Cool for a couple of minutes on the sheets, then move to a wire rack to cool completely.
        Once the whoopies are cool, spread ½ a teaspoon of dulce de leche on the flat sides.
        Peel and slice the bananas, then top half the pies with 2 slices of the banana. Sandwich together with the remaining halves, and dust with icing sugar and cocoa powder.
        Source: https://www.jamieoliver.com/recipes/chocolate-recipes/chocolate-amp-banoffee-whoopie-pies/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 heaped tablespoons cocoa powder , plus extra for dusting",
          "350 g self-raising flour",
          "175 g sugar",
          "200 ml milk",
          "100 ml nut or rapeseed oil",
          "1 large free-range egg",
          "240 g dulce de leche",
          "3 bananas",
          "icing sugar , for dusting",
        ],
        "category": "American", 
        "image": "chocolate-banoffee-whoopie-pies.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Grilled Lobster Rolls",
        "description": `Remove the butter from the fridge and allow to soften. Preheat a griddle pan until really hot.
        Butter the rolls on both sides and grill on both sides until toasted and lightly charred (keep an eye on them so they don’t burn).
        Trim and dice the celery, chop the lobster meat and combine with the mayonnaise. Season with sea salt and black pepper to taste. Open your warm grilled buns, shred and pile the lettuce inside each one and top with the lobster mixture. Serve immediately.
        Source: https://www.jamieoliver.com/recipes/seafood-recipes/grilled-lobster-rolls/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "85 g butter",
          "6 submarine rolls",
          "500 g cooked lobster meat, from sustainable sources",
          "1 stick of celery",
          "2 tablespoons mayonnaise , made using free-range eggs",
          "½ an iceberg lettuce",
        ],
        "category": "American", 
        "image": "grilled-lobster-rolls.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Southern Fried Chicken",
        "description": `To make the brine, toast the peppercorns in a large pan on a high heat for 1 minute, then add the rest of the brine ingredients and 400ml of cold water. Bring to the boil, then leave to cool, topping up with another 400ml of cold water. Meanwhile, slash the chicken thighs a few times as deep as the bone, keeping the skin on for maximum flavour. Once the brine is cool, add all the chicken pieces, cover with clingfilm and leave in the fridge for at least 12 hours.
        
        Source: https://www.jamieoliver.com/recipes/chicken-recipes/southern-fried-chicken/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "4 free-range chicken thighs , skin on, bone in",
          "4 free-range chicken drumsticks",
          "200 ml buttermilk",
          "4 sweet potatoes",
          "200 g plain flour",
          "1 level teaspoon baking powder",
          "1 level teaspoon cayenne pepper",
          "1 level teaspoon hot smoked paprika",
          "1 level teaspoon onion powder",
          "1 level teaspoon garlic powder",
          "2 litres groundnut oil",
         
        ],
        "category": "American", 
        "image": "southern-fried-chicken.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Key Lime Pie",
        "description": `Preheat the oven to 175ºC/gas 3. Lightly grease a 22cm metal or glass pie dish with a little of the butter. For the pie crust, blend the biscuits, sugar and remaining butter in a food processor until the mixture resembles breadcrumbs. Transfer to the pie dish and spread over the bottom and up the sides, firmly pressing down. Bake for 10 minutes, or until lightly browned. Remove from oven and place the dish on a wire rack to cool. For the filling, whisk the egg yolks in a bowl. Gradually whisk in the condensed milk until smooth.
        Mix in 6 tablespoons of lime juice, then pour the filling into the pie crust and level over with the back of a spoon. Return to the oven for 15 minutes, then place on a wire rack to cool. Once cooled, refrigerate for 6 hours or overnight. To serve, whip the cream until it just holds stiff peaks. Add dollops of cream to the top of the pie, and grate over some lime zest, for extra zing if you like. Source: https://www.jamieoliver.com/recipes/fruit-recipes/key-lime-pie/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "4 large free-range egg yolks",
          "400 ml condensed milk",
          "5 limes",
          "200 ml double cream",
          "135 g unsalted butter",
          "12 digestive biscuits",
          "45 g caster sugar",
        ],
        "category": "American", 
        "image": "key-lime-pie.jpg",
        "createdDate": "7/14/2022"
      },


      // thai

      { 
        "name": "Thai-style Mussels",
        "description": `Wash the mussels thoroughly, discarding any that aren’t tightly closed.
        Trim and finely slice the spring onions, peel and finely slice the garlic. Pick and set aside the coriander leaves, then finely chop the stalks. Cut the lemongrass into 4 pieces, then finely slice the chilli.
        In a wide saucepan, heat a little groundnut oil and soften the spring onion, garlic, coriander stalks, lemongrass and most of the red chilli for around 5 minutes.
        Source: https://www.jamieoliver.com/recipes/seafood-recipes/thai-style-mussels/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 kg mussels , debearded, from sustainable sources",
          "4 spring onions",
          "2 cloves of garlic",
          "½ a bunch of fresh coriander",
         
        ],
        "category": "Thai", 
        "image": "thai-style-mussels.jpg",
        "createdDate": "7/14/2022"
      },

      
      { 
        "name": "Thai green chicken curry",
        "description": `To make the curry paste, peel, roughly chop and place the garlic, shallots and ginger into a food processor. Trim the lemongrass, remove the tough outer leaves, then finely chop and add to the processor. Trim and add the chillies along with the cumin and half the coriander (stalks and all). Blitz until finely chopped, add the fish sauce and blitz again.
        Source: https://www.jamieoliver.com/recipes/chicken-recipes/thai-green-chicken-curry/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "750 g skinless free-range chicken thighs",
          "groundnut oil",
          "400 g mixed oriental mushrooms",
          "1 x 400g tin of light coconut milk",
          "1 organic chicken stock cube",
         
        ],
        "category": "Thai", 
        "image": "thai-green-chicken-curry.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Thai red chicken soup",
        "description": `Sit the chicken in a large, deep pan.
        Carefully halve the squash lengthways, then cut into 3cm chunks, discarding the seeds.
        Slice the coriander stalks, add to the pan with the squash, curry paste and coconut milk, then pour in 1 litre of water. Cover and simmer on a medium heat for 1 hour 20 minutes.
        Source: https://www.jamieoliver.com/recipes/chicken-recipes/thai-red-chicken-soup/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 x 1.6 kg whole free-range chicken",
          "1 butternut squash (1.2kg)",
          "1 bunch of fresh coriander (30g)",
          "100 g Thai red curry paste",
          "1 x 400 ml tin of light coconut milk",
         
        ],
        "category": "Thai", 
        "image": "thai-red-chicken-soup.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Veggie pad Thai",
        "description": `Cook the noodles according to the packet instructions, then drain and refresh under cold running water and toss with 1 teaspoon of sesame oil.
        Lightly toast the peanuts in a large non-stick frying pan on a medium heat until golden, then bash in a pestle and mortar until fine, and tip into a bowl.
        Source: https://www.jamieoliver.com/recipes/vegetable-recipes/veggie-pad-thai/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "150 g rice noodles",
          "sesame oil",
          "20 g unsalted peanuts",
         
        ],
        "category": "Thai", 
        "image": "veggie-pad-thai.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Prawn & tofu pad Thai",
        "description": `Cook the rice noodles according to the packet instructions.
        Meanwhile, make the tamarind sauce. Coarsely grate the palm sugar into a bowl, add the tamarind paste, 1 tablespoon of fish sauce, a dash of vinegar and 2 tablespoons of boiling water and mix well so the sugar dissolves. Taste, and adjust the flavours if needed – you’re looking for sweet, sour and slightly salty.
        Source: https://www.jamieoliver.com/recipes/seafood-recipes/prawn-tofu-pad-thai/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "150 g flat rice noodles",
          "1 fresh bird's-eye chilli",
          "1 fresh yellow chilli",
          "2 limes",
         
        ],
        "category": "Thai", 
        "image": "prawn-tofu-pad-thai.jpg",
        "createdDate": "7/14/2022"
      },

      // mexican

      { 
        "name": "Mexican-style roasted veg ragù",
        "description": `Preheat the oven to 200°C/400°F/gas 6.
        Scrub 2 sweet potatoes and chop into 2.5cm cubes. Peel 300g of butternut squash or pumpkin and 2 carrots, then cut into wedges. Toss in a large roasting tray with 150g of sweetcorn.
        Source: https://www.jamieoliver.com/recipes/vegetable-recipes/mexican-style-roasted-veg-ragu/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 sweet potatoes",
          "300 g butternut squash or pumpkin",
          "2 carrots",
         
        ],
        "category": "Mexican", 
        "image": "mexican-style-roasted-veg-ragu.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Griddled avocado & broccoli tacos",
        "description": `Place a griddle pan over a high heat, scatter in 50g of pumpkin seeds and toast for 1 to 2 minutes, then remove to a bowl.
        Cut 1 head of broccoli into 1cm slices, then toss in a little olive oil and a pinch of sea salt and black pepper. Lay them on the hot griddle and cook for 3 to 4 minutes on each side, or until charred and just cooked through – you want them to retain a bit of bite.
        Source: https://www.jamieoliver.com/recipes/avocado-recipes/avocado-and-broccoli-tacos/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "50 g pumpkin seeds",
          "1 head of broccoli",
          "olive oil",
        ],
        "category": "Mexican", 
        "image": "avocado-and-broccoli-tacos.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Veggie black bean enchiladas",
        "description": `Preheat the oven to 180ºC/350ºF/gas 4.
        Halve, deseed and remove the stalks from 2 red peppers and 2 fresh red chillies.
        Blacken and char 6 spring onions, 400g of tomatoes, the peppers, chillies, and 2 cloves of garlic in a large dry ovenproof non-stick pan (or directly over the flame of a gas hob) on a high heat – you may need to work in batches.
        Source: https://www.jamieoliver.com/recipes/vegetables-recipes/my-veggie-black-bean-enchiladas/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 red peppers",
          "2 fresh red chillies",
          "8 spring onions",
         
        ],
        "category": "Mexican", 
        "image": "veggie-black-bean-enchiladas.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Roasted sweet potato burrito",
        "description": `Preheat the oven to 180°C/350°F/gas 4.
        Cut 600g of sweet potatoes into rough 3cm chunks, then toss in a roasting tin with 1 tablespoon of olive oil and a pinch of sea salt and black pepper. Roast for 40 minutes, or until soft, golden and gnarly.
        Place a small pan on a medium heat with 1 teaspoon of olive oil.
        Source: https://www.jamieoliver.com/recipes/vegetable-recipes/roasted-sweet-potato-burrito/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 medium sweet potatoes , (600g)",
          "olive oil",
          "2 cloves of garlic",
         
        ],
        "category": "Mexican", 
        "image": "roasted-sweet-potato-burrito.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Veggie quesadillas",
        "description": `Peel off the outer layers of the leeks, leaving the tender inner part (save the outsides for stew or soup, or even stock or gravy), then finely chop.
        Deseed and finely chop the peppers. Wash and coarsely grate the carrot.
        Put all the veg in a bowl, coarsely grate in the cheese, adding more if you have it, then mix it all together. If you’ve got fresh herbs, add some roughly chopped leaves.
        Source: https://www.jamieoliver.com/recipes/vegetable-recipes/veggie-quesadillas/ `,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "3 leeks",
          "3 peppers",
          "1 large carrot",
         
        ],
        "category": "Mexican", 
        "image": "veggie-quesadillas.jpg",
        "createdDate": "7/14/2022"
      },


      // indian
      

      { 
        "name": "Plaintain Dosa",
        "description": `To make the dosa batter, wash the dal and rice thoroughly, then drain and soak in 900ml of fresh water with the fenugreek seeds, covered, for 6-12 hours or until the grains have swelled and softened.
        Tip the mixture into a blender and whiz until smooth, then transfer to a non-metallic bowl. Cover and set aside overnight, or until the mixture is frothy, light and full of volume.
        Source: https://www.jamieoliver.com/recipes/vegetable-recipes/jamie-s-special-dosa/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "3 red onions",
          "500 g Maris Piper potatoes",
          "1 plantain",
         
        ],
        "category": "Indian", 
        "image": "jamie-s-special-dosa.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Silky masala eggs",
        "description": `Preheat the oven to 160ºC/325ºF/gas 3.
        On a chopping board, peel and finely slice the onion, deseed and finely slice the chilli, then peel and crush the garlic.
        Pick and roughly chop the coriander leaves, finely chopping the stalks.
        Source: https://www.jamieoliver.com/recipes/egg-recipes/silky-masala-eggs/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 small red onion",
          "1 fresh red or green chilli",
          "1 clove of garlic",
         
        ],
        "category": "Indian", 
        "image": "silky-masala-eggs.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Mango Chutney",
        "description": `Peel, stone and roughly chop the mangos; set aside.
        Remove the cardamom seeds from the pods. Peel and finely chop the garlic, then trim and finely chop the chilli.
        Pick and roughly chop the coriander leaves, finely chopping the stalks.
        Source: https://www.jamieoliver.com/recipes/fruit-recipes/mango-chutney/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "2 kg mangos (firm, but ripe)",
          "8 cardamom pods",
          "2 cloves of garlic",
         
        ],
        "category": "Indian", 
        "image": "mango-chutney.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Bombay Omelette",
        "description": `Peel and finely chop the onion. Halve the tomatoes, scoop out the seeds with a teaspoon and discard, then finely chop the flesh.
        Finely chop the coriander stalks and leaves. Halve the chilli, deseed and finely slice.
        Source: https://www.jamieoliver.com/recipes/egg-recipes/bombay-omelette/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "½ a red onion",
          "2 small vine tomatoes",
          "½ a bunch of fresh coriander",
         
        ],
        "category": "Indian", 
        "image": "bombay-omelette.jpg",
        "createdDate": "7/14/2022"
      },

      { 
        "name": "Roasted veggie curry",
        "description": `Preheat the oven to 200ºC/400ºF/gas 6.
        In a large roasting tray, mix the curry paste with a pinch of sea salt, 2 tablespoons of oil and 1 tablespoon of vinegar.
        Wash the parsnip, carrots and butternut squash (we’re leaving the skins on). Quarter the parsnip lengthways, remove the fluffy core and chop into bite-sized chunks (about 2cm), adding to the tray as you go.
        Source: https://www.jamieoliver.com/recipes/curry-recipes/roasted-veggie-curry/`,
        "email": "456.hira@gmail.com",
        "author": "Hira Javaid",
        "ingredients": [
          "1 heaped teaspoon Madras curry paste",
          "olive oil",
          "red wine vinegar",
         
        ],
        "category": "Indian", 
        "image": "roasted-veggie-curry.jpg",
        "createdDate": "7/14/2022"
      },


      
    ]);
  } catch (error) {
    console.log('err', + error)
  }
}

insertDymmyRecipeData();

